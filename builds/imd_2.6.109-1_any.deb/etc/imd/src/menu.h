#ifndef __IMD_MENU_H__
#define __IMD_MENU_H__

#include "settings.h"

void menu (struct Settings*);

#endif
