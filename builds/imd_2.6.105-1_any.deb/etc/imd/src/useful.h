#ifndef __IMD_USEFUL_H__
#define __IMD_USEFUL_H__

size_t intLen   (int);
char   keypress ();
int    isNum    (char*);
int    toNum    (char*);

#endif
