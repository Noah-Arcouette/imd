#ifndef __READER_H__
#define __READER_H__
#include "settings.h"

char* reader (struct Settings*);

#endif
