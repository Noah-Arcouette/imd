#ifndef __IMD_VERSION_INFO__
#define __IMD_VERSION_INFO__
# define IMD_VERSION "2.6"
# define IMD_REVS "113"
#endif
